import { LightningElement } from 'lwc';

export default class MetroPassForm extends LightningElement {}