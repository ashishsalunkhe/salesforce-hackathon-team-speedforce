({
	init: function (cmp, event, helper) {

        var mapMarkers = [
        {
            location: {
                // Location Information
                City: 'Pune',
                Country: 'India',
                PostalCode: '411018',
                State: 'MH',
                Street: 'Ratnaprabha Emrald, Near Mhada, Kale-Pimple Road,Waghere, 309, Pimpri',
            },

            // For onmarkerselect
            value: 'PCMC',

            // Extra info for tile in list and info window
            icon: 'standard:account',
            title: 'Oasis Multispeciality Hospital', // e.g. Account.Name
            description: 'Ratnaprabha Emrald, Near Mhada, Kale-Pimple Road,Waghere, 309, Pimpri'
        },
        {
            location: {
                // Location Information
                City: 'Pune',
                Country: 'India',
                PostalCode: '411018',
                State: 'MH',
                Street: 'YCM Hospital Rd, Sant Tukaram Nagar, Pimpri Colony, Pune, Maharashtra 411018',
            },

            // For onmarkerselect
            value: 'YCM',

            // Extra info for tile in list
            icon: 'standard:account',
            title: 'Yashwantrao Chavan Memorial Hospital', // e.g. Account.Name
            description: 'YCM Hospital Rd, Sant Tukaram Nagar, Pimpri Colony, Pune, Maharashtra 411018'
        },
        {
            location: {
                // Location Information
                City: 'Pune',
                Country: 'India',
                PostalCode: '411044',
                State: 'MH',
                Street: 'Church, Near Akurdi, Shri Mhalsakant Vidyalaya Rd, 3695 Akurdi, Pimpri-Chinchwad, Maharashtra 411044',
            },

            // For onmarkerselect
            value: 'APH',

            // Extra info for tile in list
            icon: 'standard:account',
            title: 'Akurdi PCMC Hospital', // e.g. Account.Name
            description: 'Church, Near Akurdi, Shri Mhalsakant Vidyalaya Rd, 3695 Akurdi, Pimpri-Chinchwad, Maharashtra 411044'
        },
        {
            location: {
                // Location Information
                City: 'Pune',
                Country: 'India',
                PostalCode: '411018',
                State: 'MH',
                Street: 'Shubham Galleria, bridge, next to chroma, near pimpri, MIDC, Pimpri Colony, Pimpri-Chinchwad, Maharashtra 411018',
            },

            // For onmarkerselect
            value: 'CPC',

            // Extra info for tile in list
            icon: 'standard:account',
            title: 'CitiCare Pimpri Chinchwad', // e.g. Account.Name
            description: 'Shubham Galleria, bridge, next to chroma, near pimpri, MIDC, Pimpri Colony, Pimpri-Chinchwad, Maharashtra 411018'
        }
    ];

    cmp.set('v.mapMarkers', mapMarkers);
    cmp.set('v.center', {
            location: {
                Latitude: '18.6298',
                Longitude: '73.7997',
            },
        });
    },

    handleMarkerSelect: function (cmp, event, helper) {
        var marker = event.getParam("selectedMarkerValue");
    }
})