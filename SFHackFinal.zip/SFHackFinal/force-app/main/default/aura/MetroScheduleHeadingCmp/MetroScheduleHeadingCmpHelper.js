({
	onKeyupEventHandler : function(component, event, helper) {
		var localId = event.getSource().getLocalId();
        console.log("localId->" + localId);
	}, 
    matchStringRegexForValidation : function(text) {
        debugger;
        var validLang = "/^[A-Z+a-z]+$/";
        console.log("text for Regex" + text);
        console.log("typeofText" + typeof text);
        if(typeof text == "string") {
            if(/^[A-Z+a-z]+$/.test(text)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    },
    validateTextHelper : function(component, event, helper) {
        debugger;
        var textVal = event.getSource().get("v.value");
        console.log("TextValue->" + textVal);
        if($A.util.isUndefinedOrNull(textVal) || $A.util.isEmpty(textVal)) {
            component.set("v.isCmpValid", false);   
        } else {
            var isTextValid = helper.matchStringRegexForValidation(textVal);
            console.log("isTextValid" + isTextValid);
            if(!isTextValid) {
                component.set("v.isCmpValid", false);     
            }
        }
    },
    showErrorMsgs : function(errorMsgs) {
        debugger;
        for(var i in errorMsgs) {
            console.log("i" + i);
            console.log("msg->" + errorMsgs);
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message: errorMsgs[i].message,
                duration:' 5000',
                key: 'info_alt',
                type: 'error',
                mode: 'pester'
            });
            toastEvent.fire();
        }
    }, 
    getAvailableMetroSlots : function(component, event, helper) {
        var action = component.get("c.getMetroSlots");
        action.setCallback(this, function(response){
            var state = response.getState();
            var responseSlots = response.getReturnValue();
            console.log("state->" + state);
            console.log("slots->" + responseSlots);
            if(state==="SUCCESS" && !$A.util.isEmpty(responseSlots)) {
				component.set("v.metroSlot", responseSlots);                
            } else {
                component.set("v.metroSlot", ["Metro Slots Not Available"]);                
            }
        });
        $A.enqueueAction(action);
    }, 
    validateComponent : function(component, event, helper) { 
        debugger;
        var errorMsgs = [];
        var allValid = component.find('inp-field').reduce(function (validSoFar, inputCmp) {
            console.log(inputCmp);
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);
        if (allValid) {
            console.log("All valid");
        } else {
            var errMsg = {message : "Please enter data required fields"};
            errorMsgs.push(errMsg);
        }
        component.set("v.cmpErrMsg", errorMsgs);
        if(!$A.util.isEmpty(errorMsgs) && !$A.util.isUndefinedOrNull(errorMsgs)) {
            this.showErrorMsgs(errorMsgs);            
        }
        this.validateSourceDest(component, event, helper);
    },
    getMetroStation : function(component, event, helper) {
        debugger;
        var action = component.get("c.getMetroStations");
        action.setCallback(this, function(response) {
            debugger;
            var state = response.getState();
            var respMetroStations = response.getReturnValue();
            console.log("state->" + state);
            console.log("metrostations->" + respMetroStations);
            if(state==="SUCCESS" && !$A.util.isEmpty(respMetroStations)) {
                component.set("v.stationList", respMetroStations);                
            } else {
                component.set("v.stationList", ["No Station Available"]);                
            }            
        });
        $A.enqueueAction(action);
    },
    validateSourceDest : function(component, event, helper) {
        debugger;
        var source = component.get("v.sourceSearch");
        var dest = component.get("v.destinationSearch");
        var errorMsgs = [];
        if((!$A.util.isUndefinedOrNull(source) || !$A.util.isUndefinedOrNull(dest)) && source===dest) {
            var errMsg = {message : "Source and destination cannot be same"};
            errorMsgs.push(errMsg);  
            component.set("v.cmpErrMsg", errorMsgs);
			component.set("v.isCmpValid" ,false)
        }
        if(!$A.util.isEmpty(errorMsgs) && !$A.util.isUndefinedOrNull(errorMsgs)) {
            this.showErrorMsgs(errorMsgs);            
        }

    },
    searchMetroHelper : function(component, event, helper) {
        debugger;
        component.set("v.metroStatJuncList", "");
        var action = component.get("c.getAvailableMetros");
        console.log("**->" + component.get("v.sourceSearch"));
        console.log("**->" + component.get("v.destinationSearch"));
        console.log("**->" + component.get("v.journeyDate"));
        console.log("**->" + component.get("v.selectedSlot"));
        
        action.setParams({
            "source" : component.get("v.sourceSearch"),
            "dest" : component.get("v.destinationSearch"),
            "journeyDate" : component.get("v.journeyDate"),
            "slot" :  component.get("v.selectedSlot")
        });
        
        action.setCallback(this, function(response) {
            debugger;
            var state = response.getState();
            var responseMap = response.getReturnValue();
            var errorMsgs = [];
            console.log("available metros->" + state);
            console.log("available metros->" + JSON.stringify(responseMap));
            console.log("available metros-> success" + responseMap["SUCCESS"]);
            console.log("available metros-> error" + responseMap["ERROR"]);
            if(state==="SUCCESS" && !$A.util.isUndefinedOrNull(responseMap) && !$A.util.isEmpty(responseMap)) {
                if(!$A.util.isUndefinedOrNull(responseMap["SUCCESS"]) && !$A.util.isEmpty(responseMap["SUCCESS"])) {
                    var metroStatJunc = responseMap["SUCCESS"];
                    component.set("v.renderTable", true);
                    component.set("v.metroStatJuncList",  responseMap["SUCCESS"]);
                    console.log("data->" + component.get("v.metroStatJuncList"));
                } else if(!$A.util.isUndefinedOrNull(responseMap["ERROR"]) && !$A.util.isEmpty(responseMap["ERROR"])) {
                    var errMsg = {message : "No metro available from selected source to destination and on selected slot"};
                    errorMsgs.push(errMsg);  
                }
            } else {
                var errMsg = {message : "Server Issue."};
                errorMsgs.push(errMsg);  
            }
            component.set("v.cmpErrMsg", errorMsgs);
            if(!$A.util.isEmpty(errorMsgs) && !$A.util.isUndefinedOrNull(errorMsgs)) {
                this.showErrorMsgs(errorMsgs);            
            }
        });
        $A.enqueueAction(action);
    }
})