({
    doInit : function(component, event, helper) {
        debugger;
        component.set("v.isloading", true);
        helper.getAvailableMetroSlots(component, event, helper);
        helper.getMetroStation(component, event, helper);
        component.set("v.isloading", false);
    },
    validateText : function(component, event, helper) {
        debugger;
		console.log("Validating Text");
        helper.validateTextHelper(component, event, helper);
        helper.validateSourceDest(component, event, helper);
    },
    onSearchMetros : function(component, event, helper) {
        debugger;
        console.log("Search Metros Clicked");
        helper.validateComponent(component, event, helper);
        var isCmpValid = component.get("v.isCmpValid");
        console.log("isCmpValid" + isCmpValid);
        if(isCmpValid) {
            console.log("Valid Cmp");
            //Call Helper method and show Timelines then
            //Logic is Give Serial Number for Station like 1 - 2 i.e from source to destination
            //or make search type of input and then valid text only in that
            component.set("v.renderTable", false);
            helper.searchMetroHelper(component, event, helper);
        } else {
            var showToast = $A.get("e.force:showToast");
            showToast.setParams({
                title : "Error!!!",
                message : "Please enter relevant Data",
                type : "error",
                mode : "pester",
                duration : 5000
            });
            showToast.fire();
            component.set("v.isCmpValid", true);
        }
    },
    validateDate : function(component, event, helper) {
        debugger;
    	var auraId = event.getSource().getLocalId();
        var selectedDateString = component.find(auraId).get("v.value").split("-");
        var todaysDate = new Date();
        var selectedDate = new Date(selectedDateString[0], selectedDateString[1], selectedDateString[2]);
        var errorMsgs = [];
        component.set("v.cmpErrMsg", null);
        console.log("selectedDate->" + typeof selectedDate);
        console.log("todaysDate->" + todaysDate);
        console.log("selectedDate->" + selectedDate);
        if(selectedDate.getFullYear() >= todaysDate.getFullYear()) {
            if(selectedDate.getMonth() >= todaysDate.getMonth()) {
                if(selectedDate.getDate() >= todaysDate.getDate()) {
                    component.set("v.isCmpValid", true);                       
                } else {
                    var errMsg = {message : "Cannot select previous date"};
                    errorMsgs.push(errMsg);
                    component.set("v.isCmpValid", false);   
                }
            } else {
                var errMsg = {message : "Cannot select previous month"};
                errorMsgs.push(errMsg);
                component.set("v.isCmpValid", false);   
            }
        } else {
            var errMsg = {message : "Cannot select previous years"};
            errorMsgs.push(errMsg);
            component.set("v.isCmpValid", false);   
        } 
        component.set("v.cmpErrMsg", errorMsgs);
        if(!$A.util.isEmpty(errorMsgs) && !$A.util.isUndefinedOrNull(errorMsgs)) {
            helper.showErrorMsgs(errorMsgs);            
        }
    },
    
    
})