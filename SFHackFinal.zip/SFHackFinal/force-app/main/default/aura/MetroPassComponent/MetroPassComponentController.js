({
    doInit : function(component, event, helper) {
        helper.getUserDataBeforeBooking(component, event, helper);
    }
})