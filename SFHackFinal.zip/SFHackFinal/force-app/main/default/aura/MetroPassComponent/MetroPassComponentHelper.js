({
    getUserDataBeforeBooking : function(component, event, helper) {
        var errorMsgs = [];
        var action = component.get("c.getUserData");
        action.setCallback(this, function(response) {
            debugger;
			var state = response.getState();
			var userMap = response.getReturnValue();
			console.log("$$" + state);
			console.log("$$" + userMap);            
            if(state==="SUCCESS" && !$A.util.isUndefinedOrNull(userMap)  && !$A.util.isEmpty(userMap)) {
				component.set("v.userId", userMap['userId']);
                component.set("v.firstName", userMap['FirstName']);
                component.set("v.contactId", userMap['contactId']);
                component.set("v.email", userMap['email']);
                component.set("v.userName", userMap['UserName']);
            } else {
                var errMsg = {message : "Please Login to Issue Pass"};
                errorMsgs.push(errMsg);
                if(!$A.util.isEmpty(errorMsgs) && !$A.util.isUndefinedOrNull(errorMsgs)) {
                    this.showErrorMsgs(errorMsgs);            
                }
            }
        });
        $A.enqueueAction(action);
    }, 
})