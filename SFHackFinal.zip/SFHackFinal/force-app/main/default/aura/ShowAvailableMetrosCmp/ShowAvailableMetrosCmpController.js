({
	doInit : function(component, event, helper) {
		//fetch arrival and deprature from metrostation junction from here in doInit 
		helper.getMaxTicketsToBookConfig(component, event, helper);
	},
    onBookNow : function(component, event, helper) {
        debugger;
        console.log("book now clicked");
        var auraId = event.getSource().getLocalId();
        console.log("auraId-->" + auraId);    
        var valueId =  event.getSource().get("v.value");
        console.log("value-->" + event.getSource().get("v.value"));
        component.set("v.selectedSlotId", valueId);
        helper.getUserDataBeforeBooking(component, event, helper);
        helper.getTimings(component, event, helper);
    },
    closeModal : function(component, event, helper) {
        component.set("v.selectedSlotId", "");
        component.set("v.showModal", false);
    },
    confirmBooking : function(component, event, helper) {
        debugger;
        var source = component.get("v.sourceSearch");
        var dest = component.get("v.destinationSearch");
        var custName =  component.get("v.firstName");
        var metroSlotId = component.get("v.selectedSlotId");
        var journeyDate = component.get("v.journeyDate");
        var contactId = component.get("v.contactId");
        var userId = component.get("v.userId");
        var noOfTickets = component.get("v.ticketCnt");
        console.log("%%" + source);
        console.log("%%" + dest);
        console.log("%%" + custName);
        console.log("%%" + metroSlotId);
        console.log("%%" + journeyDate);
        console.log("%%" + contactId);
        console.log("%%" + noOfTickets);
        var action = component.get("c.bookTicket");
        action.setParams({
            "source" : source,
            "destination" : dest,
            "customerName" : custName,
            "metroSlot" : metroSlotId,
            "journeyDay" : journeyDate,
            "contactId" : contactId,
            "ticketUser" : userId, 
            "seatCnt" : noOfTickets
        });
        action.setCallback(this, function(response){
            debugger;
            var state = response.getState();
            var responseVal = response.getReturnValue();
            console.log("%%" + responseVal);
            console.log("%% success" + responseVal["SUCCESS"]);
            console.log("%% errorr" + responseVal["ERROR"]);
            if(state === "SUCCESS" && !$A.util.isUndefinedOrNull(responseVal) && !$A.util.isEmpty(responseVal)) {
                if(!$A.util.isUndefinedOrNull(responseVal["SUCCESS"]) && !$A.util.isEmpty(responseVal["SUCCESS"])) {
                    var successValue = responseVal["SUCCESS"];
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success',
                        message: successValue,
                        duration:' 5000',
                        key: 'info_alt',
                        type: 'success',
                        mode: 'pester'
                    });
                    toastEvent.fire();                    
                } else if(!$A.util.isUndefinedOrNull(responseVal["ERROR"]) && !$A.util.isEmpty(responseVal["ERROR"])) {
                    var errorMsg = responseVal["ERROR"];
                    var errorMsgs = {message : errorMsg};
                    if(!$A.util.isEmpty(errorMsgs) && !$A.util.isUndefinedOrNull(errorMsgs)) {
                        helper.showErrorMsgs([errorMsgs]);            
                    }   
                }
            }
            
        });
        $A.enqueueAction(action);
    }
})