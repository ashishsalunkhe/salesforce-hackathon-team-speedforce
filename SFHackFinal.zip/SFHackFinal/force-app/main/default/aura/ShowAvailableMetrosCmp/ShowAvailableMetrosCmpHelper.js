({
	getTimings : function(component, event, helper) {
        debugger;
		var action = component.get("c.getArrivalDepartureTimes");
        action.setParams({
            "sourceSearch" : component.get("v.sourceSearch"),
            "destSearch" : component.get("v.destinationSearch"),
            "metroSlotId" : component.get("v.selectedSlotId")            
        });
        action.setCallback(this, function(response) {
            debugger;
            var state = response.getState();
            var responseMap = response.getReturnValue();
            console.log("$" + state);
            console.log("$" + responseMap);
            if(state==="SUCCESS" && !$A.util.isUndefinedOrNull(responseMap) && !$A.util.isEmpty(responseMap)) {
                if(!$A.util.isUndefinedOrNull(responseMap["SOURCEDEPTTIME"])) {
                    component.set("v.arrivalTime", responseMap["SOURCEDEPTTIME"]);
                }
                if(!$A.util.isUndefinedOrNull(responseMap["DESTARRTIME"])) {
                    component.set("v.deptTime", responseMap["DESTARRTIME"]);
                }
            }
        });
        $A.enqueueAction(action);
	},
    getUserDataBeforeBooking : function(component, event, helper) {
        var errorMsgs = [];
        var action = component.get("c.getUserData");
        action.setCallback(this, function(response) {
            debugger;
			var state = response.getState();
			var userMap = response.getReturnValue();
			console.log("$$" + state);
			console.log("$$" + userMap);            
            if(state==="SUCCESS" && !$A.util.isUndefinedOrNull(userMap)  && !$A.util.isEmpty(userMap)) {
				component.set("v.userId", userMap['userId']);
                component.set("v.firstName", userMap['FirstName']);
                component.set("v.contactId", userMap['contactId']);
                component.set("v.email", userMap['email']);
                component.set("v.userName", userMap['UserName']);
                component.set("v.showModal", true);
            } else {
                var errMsg = {message : "Please Login to book"};
                errorMsgs.push(errMsg);
                if(!$A.util.isEmpty(errorMsgs) && !$A.util.isUndefinedOrNull(errorMsgs)) {
                    this.showErrorMsgs(errorMsgs);            
                }
            }
        });
        $A.enqueueAction(action);
    }, 
    showErrorMsgs : function(errorMsgs) {
        debugger;
        for(var i in errorMsgs) {
            console.log("i" + i);
            console.log("msg->" + errorMsgs);
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message: errorMsgs[i].message,
                duration:' 5000',
                key: 'info_alt',
                type: 'error',
                mode: 'pester'
            });
            toastEvent.fire();
        }
    },
    getMaxTicketsToBookConfig : function(component, event, helper) {
        var action = component.get("c.getMaxTicketToBook");
        action.setCallback(this, function(response) {
            var state = response.getState();
            var labelVal = response.getReturnValue();
            console.log("$$" + state);
            console.log("$$" + labelVal);            
            component.set("v.maxTicketToBook", labelVal);
        });
        $A.enqueueAction(action);
    }
})