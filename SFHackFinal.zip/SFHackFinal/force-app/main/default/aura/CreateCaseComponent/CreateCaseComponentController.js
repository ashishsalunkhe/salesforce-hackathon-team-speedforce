({
    handleCreateCase: function(component, event) {
        var saveCaseAction = component.get("c.createCase");
            saveCaseAction.setParams({
                "cases": component.get("v.newCase")
            });
        
        // Configure the response handler for the action
        saveCaseAction.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                component.set("v.message", "Case created successfully");
            }
            else if (state === "ERROR") {
                console.log('Problem saving contact, response state: ' + state);
            }
            else {
                console.log('Unknown problem, response state: ' + state);
            }
        });
 
        // Send the request to create the new case
        $A.enqueueAction(saveCaseAction);
    },
})