({
	init: function (cmp, event, helper) {

        var mapMarkers = [
        {
            location: {
                // Location Information
                City: 'Pune',
                Country: 'India',
                PostalCode: '411018',
                State: 'MH',
                Street: 'Old Mumbai - Pune Hwy, Pimpri Gaon, Pimpri Colony, Pune, Maharashtra 411018',
            },

            // For onmarkerselect
            value: 'PCMC',

            // Extra info for tile in list and info window
            icon: 'standard:account',
            title: 'PCMC Station', // e.g. Account.Name
            description: 'Stop 1'
        },
        {
            location: {
                // Location Information
                City: 'Pune',
                Country: 'India',
                PostalCode: '411034',
                State: 'MH',
                Street: 'Kasarwadi, Pimpri-Chinchwad, Maharashtra 411034',
            },

            // For onmarkerselect
            value: 'KSW',

            // Extra info for tile in list
            icon: 'standard:account',
            title: 'Kasarwadi Station', // e.g. Account.Name
            description: 'Stop 2'
        }
    ];

    cmp.set('v.mapMarkers', mapMarkers);
    cmp.set('v.center', {
            location: {
                Latitude: '40.7831856',
                Longitude: '-73.9675653',
            },
        });
    },

    handleMarkerSelect: function (cmp, event, helper) {
        var marker = event.getParam("selectedMarkerValue");
    }
})