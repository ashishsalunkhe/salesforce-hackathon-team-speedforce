declare module "@salesforce/apex/ZomatoClass.getLocation" {
  export default function getLocation(param: {locationName: any}): Promise<any>;
}
