declare module "@salesforce/apex/MetroScheduleCtrl.getMetroSlots" {
  export default function getMetroSlots(): Promise<any>;
}
declare module "@salesforce/apex/MetroScheduleCtrl.getAvailableMetros" {
  export default function getAvailableMetros(param: {source: any, dest: any, journeyDate: any, slot: any}): Promise<any>;
}
declare module "@salesforce/apex/MetroScheduleCtrl.getMetroStations" {
  export default function getMetroStations(): Promise<any>;
}
declare module "@salesforce/apex/MetroScheduleCtrl.getArrivalDepartureTimes" {
  export default function getArrivalDepartureTimes(param: {sourceSearch: any, destSearch: any, metroSlotId: any}): Promise<any>;
}
declare module "@salesforce/apex/MetroScheduleCtrl.getUserData" {
  export default function getUserData(): Promise<any>;
}
declare module "@salesforce/apex/MetroScheduleCtrl.getMaxTicketToBook" {
  export default function getMaxTicketToBook(): Promise<any>;
}
declare module "@salesforce/apex/MetroScheduleCtrl.bookTicket" {
  export default function bookTicket(param: {source: any, destination: any, journeyDay: any, metroSlot: any, contactId: any, customerName: any, ticketUser: any, seatCnt: any}): Promise<any>;
}
