declare module "@salesforce/apex/accWithContController.fetchAccount" {
  export default function fetchAccount(): Promise<any>;
}
