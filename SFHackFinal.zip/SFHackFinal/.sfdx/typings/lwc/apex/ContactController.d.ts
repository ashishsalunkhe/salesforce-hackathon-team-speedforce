declare module "@salesforce/apex/ContactController.createContact" {
  export default function createContact(param: {contact: any}): Promise<any>;
}
