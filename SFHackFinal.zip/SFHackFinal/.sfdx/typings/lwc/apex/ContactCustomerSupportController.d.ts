declare module "@salesforce/apex/ContactCustomerSupportController.createCase" {
  export default function createCase(param: {contactCustomerWrapper: any, recordId: any}): Promise<any>;
}
