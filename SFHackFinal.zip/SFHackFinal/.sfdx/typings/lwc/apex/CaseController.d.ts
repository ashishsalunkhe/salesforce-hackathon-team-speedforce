declare module "@salesforce/apex/CaseController.createCase" {
  export default function createCase(param: {cases: any}): Promise<any>;
}
